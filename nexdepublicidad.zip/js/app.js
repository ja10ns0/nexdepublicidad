/**
 * 
 */
var Nexapp = Nexapp || {};

$(function() {
    Nexapp.Router = new Nexapp.Router();
    Backbone.history.start();;
})